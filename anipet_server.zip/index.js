let express = require("express");
let axios = require("axios");
const path = require('path');
const mysql = require("mysql2");
const multer = require("multer");
const bodyParser = require('body-parser');
const fs = require("fs");

let app = express();
let port = 3000;
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static("public_html"));

app.listen(port, function () {
  console.log("HTML 서버 시작");
});

const conn = {
  host: '127.0.0.1',
  port: '3306',
  user: 'root',
  password: '12345',
  database: 'anipet'
}

let connection = mysql.createConnection(conn); // DB 커넥션 생성
connection.connect();   // DB 접속



app.get('/map', (req, res) => res.sendFile(path.join(__dirname, './public_html/index.html')));


//예약 내용 db에 insert
app.post('/reservation/request', (req, res) => {

  const hospitalName = req.body.hospitalName;
  const reservationDay = req.body.reservationDay;
  const reservationTime = req.body.reservationTime;
  const petName = req.body.petName;
  const breed = req.body.breed;
  const age = req.body.age;
  const visitiongReason = req.body.visitingReasonTextController;

  // 쿼리 생성
  const sql = 'INSERT INTO user SET ?';

  const rowToInsert =
  {
    address: address,
    reservation: reservation,
    species: species,
    sympton: sympton
  };

  // 쿼리 실행
  connection.query(query, rowToInsert, (error, results, fields) => {
    if (error) {
      console.log('예약처리 중 오류 발생');
      res.writeHead('400', { 'Content-Type': 'text; charset=utf8' })
    };
    console.log('삽입된 행 수:', results.affectedRows);
    res.writeHead('200', { 'Content-Type': 'text; charset=utf8' });
    res.end();
  });
});



app.post('/users', (req, res) => {
  connection.query('SELECT * from hospital', (error, rows) => {
    if (error) throw error;
    res.send(rows);
  });
});

app.get('/users', (req, res) => {
  connection.query('SELECT * from hospital', (error, rows) => {
    if (error) throw error;
    res.send(rows);
  });
});



app.use('/uploads', express.static(__dirname + '/uploads'));
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => 
    {
      cb(null, 'uploads');
    },
    filename: (req, file, cb) => {
      cb(null,file.originalname);
    }
  }),
})


app.post('/community/add_post', upload.single('image'), async (req, res) => {


  console.log("커뮤니티 시작");
  let data = { title: req.body['title'],content:req.body['content']};
  const file = req.file;


  let sql = 'select MAX(post_id) as maxId from post;'
  connection.query(sql, (error, rows) => {
    if (error) throw error;


    let post_id;

    //db에 있는 post_id 중 가장 큰 값에 1을 더해서 새로 추가되는 post_id를 만듦
    if(rows[0].maxId == 0 )
    {
         post_id = 0;
    } else
    {
       post_id = rows[0].maxId+1;
    }   


    const user_id= 'bbb'; //이건 나중에 flutter에서 user_id보내오는걸 받는 식으로 해야 함.
    const title = data.title;
    const content = data.content;
    const like_number = 0;
    const comment_number = 0;
    const image_url = './uploads/'+file.filename;

    const v = [
      [post_id, user_id, content, like_number, comment_number, title,image_url]
    ];

    sql = 'INSERT INTO post(post_id, user_id, content, like_number,comment_number, title,image_url) VALUES ?';
    // 쿼리 실행
    connection.query(sql, [v], (error, results, fields) => {
      if (error) {
        console.log('포스트 추가 중 오류 발생');
        res.status(400).send('포스트 추가 중 오류 발생');
      } else {
        console.log('포스트가 추가되었습니다');
        res.status(200).send('포스트가 추가되었습니다');
      }
    });

  });

});




/*post 테이블에서 title,image,content 불러와서 send*/
app.post('/my_page', (req, res) => {

  const data = req.body;
  const user_id = 'bbb';


  console.log('마이 페이지');

  sql = 'SELECT * from user where user_id = ?';
  // 쿼리 실행
  const v = user_id;

  connection.query(sql, v, (error, results, fields) => {
    if (error) {

      res.status(400).send('마이 페이지 불러오기 중 오류 발생');
    } else {
      console.log(resutls);
      res.status(200).send(results);
    }
  });

});



app.post('/signup', (req, res) => {
  const data = req.body;
  const email = data.email;
  const id = data.id;
  const password = data.password;

  const v = [
    [id, email, password]
  ];

  // 쿼리 생성
  const sql = 'INSERT INTO user(user_id, email, user_pw) VALUES ?';

  // 쿼리 실행
  connection.query(sql, [v], (error, results, fields) => {
    if (error) {
      console.log('회원가입 중 오류 발생');
      res.status(400).send('회원가입 중 오류 발생');
    } else {
      console.log('회원가입이 완료되었습니다.');
      res.status(200).send('회원가입이 완료되었습니다.');
    }
  });
});

app.post('/login', (req, res) => {
  const user_id = req.body.id;
  const user_pw = req.body.password;

  let sql = 'SELECT * from user where user_id = ? and user_pw = ?';
  let values = [user_id, user_pw];

  // 로그인 처리
  connection.query(sql, values, (error, rows) => {
    if (error) {
      console.log('로그인 중 오류 발생');
      res.status(401).send('로그인 중 오류 발생');
    } else {
      if (rows.length > 0) {
        // 로그인 성공
        console.log('로그인 성공');
        res.status(200).send('로그인 성공');
      } else {
        // 로그인 실패
        console.log('로그인 중 오류 발생');
        res.status(400).send('로그인 실패');
      }
    }
  });
});


//connection.end(); // DB 접속 종료

